package ejercicio3;

public class Main {
	public static void main(String[] args) {

        AVLTree arbol = new AVLTree();

        arbol.raiz = arbol.insertar(arbol.raiz, 50);
        arbol.raiz = arbol.insertar(arbol.raiz, 30);
        arbol.raiz = arbol.insertar(arbol.raiz, 70);
        arbol.raiz = arbol.insertar(arbol.raiz, 20);
        arbol.raiz = arbol.insertar(arbol.raiz, 40);
        arbol.raiz = arbol.insertar(arbol.raiz, 60);
        arbol.raiz = arbol.insertar(arbol.raiz, 80);

        arbol.eliminar(50);
        arbol.eliminar(20);
        arbol.eliminar(80);
        arbol.eliminar(70);

        arbol.mostrarTabla();
    }
}