package ejercicio3;

class Nodo {
    int valor;
    int altura;
    int bf;       
    Nodo izq, der;
    Nodo(int valor) {
        this.valor = valor;
        this.altura = 1;
        this.bf = 0;
    }
}
