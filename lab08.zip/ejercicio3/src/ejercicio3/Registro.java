package ejercicio3;

public class Registro {
    int clave;
    String caso, sucesor, desbalance, rotacion;

    Registro(int clave, String caso, String sucesor, String desbalance, String rotacion) {
        this.clave = clave;
        this.caso = caso;
        this.sucesor = sucesor;
        this.desbalance = desbalance;
        this.rotacion = rotacion;
    }
}