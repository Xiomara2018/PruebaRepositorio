package ejercicio3;
import java.util.ArrayList;

public class AVLTree {
	 Nodo raiz;
	    ArrayList<Registro> tabla = new ArrayList<>();

	    //Obtener altura
	    int altura(Nodo n) {
	        if (n == null) {
	            return 0;
	        } else {
	            return n.altura;
	        }
	    }

	    //Máximo entre dos números
	    int max(int a, int b) {
	        if (a > b) {
	            return a;
	        } else {
	            return b;
	        }
	    }

	    //Factor de equilibrio
	    int bf(Nodo n) {
	        if (n == null) {
	            return 0;
	        } else {
	            return altura(n.izq) - altura(n.der);
	        }
	    }

	    //Actualizar altura
	    void actualizar(Nodo n) {
	        if (n != null) {
	            n.altura = 1 + max(altura(n.izq), altura(n.der));
	        }
	    }

	    //Rotación derecha
	    Nodo rotacionDerecha(Nodo y) {
	        Nodo x = y.izq;
	        Nodo T2 = x.der;

	        x.der = y;
	        y.izq = T2;

	        actualizar(y);
	        actualizar(x);

	        return x;
	    }

	    //Rotación izquierda
	    Nodo rotacionIzquierda(Nodo x) {
	        Nodo y = x.der;
	        Nodo T2 = y.izq;

	        y.izq = x;
	        x.der = T2;

	        actualizar(x);
	        actualizar(y);

	        return y;
	    }

	    //Insertar
	    Nodo insertar(Nodo nodo, int valor) {
	        if (nodo == null) {
	            return new Nodo(valor);
	        }
	        if (valor < nodo.valor) {
	            nodo.izq = insertar(nodo.izq, valor);
	        } else if (valor > nodo.valor) {
	            nodo.der = insertar(nodo.der, valor);
	        }
	        actualizar(nodo);

	        int balance = bf(nodo);

	        if (balance > 1 && valor < nodo.izq.valor) {
	            return rotacionDerecha(nodo);
	        }

	        if (balance < -1 && valor > nodo.der.valor) {
	            return rotacionIzquierda(nodo);
	        }

	        if (balance > 1 && valor > nodo.izq.valor) {
	            nodo.izq = rotacionIzquierda(nodo.izq);
	            return rotacionDerecha(nodo);
	        }

	        if (balance < -1 && valor < nodo.der.valor) {
	            nodo.der = rotacionDerecha(nodo.der);
	            return rotacionIzquierda(nodo);
	        }

	        return nodo;
	    }

	    //Buscar sucesor
	    Nodo minValor(Nodo nodo) {
	        while (nodo.izq != null) {
	            nodo = nodo.izq;
	        }
	        return nodo;
	    }

	    //ELIMINAR
	    Nodo eliminar(Nodo nodo, int clave, String[] meta) {

	        if (nodo == null) {
	            return null;
	        }

	        if (clave < nodo.valor) {
	            nodo.izq = eliminar(nodo.izq, clave, meta);
	        } else if (clave > nodo.valor) {
	            nodo.der = eliminar(nodo.der, clave, meta);
	        } else {

	            //Caso hoja
	            if (nodo.izq == null && nodo.der == null) {
	                meta[0] = "Hoja";
	                meta[1] = "-";
	                return null;
	            }

	            //Caso un hijo
	            if (nodo.izq == null || nodo.der == null) {

	                meta[0] = "Un hijo";
	                meta[1] = "-";

	                if (nodo.izq != null) {
	                    return nodo.izq;
	                } else {
	                    return nodo.der;
	                }
	            }

	            //Caso dos hijos
	            Nodo sucesor = minValor(nodo.der);

	            meta[0] = "Dos hijos";
	            meta[1] = String.valueOf(sucesor.valor);

	            nodo.valor = sucesor.valor;

	            String[] temp = new String[]{"Sin definir", "-"};
	            nodo.der = eliminar(nodo.der, sucesor.valor, temp);
	        }

	        if (nodo == null) {
	        	return null;
	        	}

	        actualizar(nodo);

	        int balance = bf(nodo);

	        String desbalance = "-";
	        if (balance > 1 || balance < -1) {
	            desbalance = String.valueOf(nodo.valor);
	        }

	        String rotacion = "-";
	        Nodo resultado = nodo;

	        // 🔹 Rotaciones
	        if (balance > 1 && bf(nodo.izq) >= 0) {
	            rotacion = "IZQ-IZQ";
	            resultado = rotacionDerecha(nodo);
	        } else if (balance > 1 && bf(nodo.izq) < 0) {
	            rotacion = "IZQ-DER";
	            nodo.izq = rotacionIzquierda(nodo.izq);
	            resultado = rotacionDerecha(nodo);
	        } else if (balance < -1 && bf(nodo.der) <= 0) {
	            rotacion = "DER-DER";
	            resultado = rotacionIzquierda(nodo);
	        } else if (balance < -1 && bf(nodo.der) > 0) {
	            rotacion = "DER-IZQ";
	            nodo.der = rotacionDerecha(nodo.der);
	            resultado = rotacionIzquierda(nodo);
	        }

	        // 🔹 Registrar solo si hubo rotación
	        if (!rotacion.equals("-")) {
	            tabla.add(new Registro(clave, meta[0], meta[1], desbalance, rotacion));
	        }

	        return resultado;
	    }

	    // eliminar
	    void eliminar(int clave) {

	        String[] meta = new String[]{"Sin definir", "-"};

	        raiz = eliminar(raiz, clave, meta);

	        boolean yaRegistrado = false;

	        if (!tabla.isEmpty()) {
	            Registro ultimo = tabla.get(tabla.size() - 1);

	            if (ultimo.clave == clave && !ultimo.rotacion.equals("-")) {
	                yaRegistrado = true;
	            }
	        }

	        if (!yaRegistrado) {
	            tabla.add(new Registro(clave, meta[0], meta[1], "-", "-"));
	        }
	    }

	    // 🔹 Mostrar tabla
	    void mostrarTabla() {
	        System.out.println("\nClave | Caso       | Sucesor | Desbalance | Rotación");
	        System.out.println("------|------------|---------|------------|----------");

	        for (Registro r : tabla) {
	            System.out.printf("%-6d| %-11s| %-8s| %-11s| %s%n",
	                    r.clave, r.caso, r.sucesor, r.desbalance, r.rotacion);
	        }
	    }
}