/**
 * 
 */
/**
 * 
 */
module VLStrabajo {
    requires java.desktop;
}