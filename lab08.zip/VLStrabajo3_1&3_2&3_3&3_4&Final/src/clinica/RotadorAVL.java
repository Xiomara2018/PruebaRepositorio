package clinica;

import javax.swing.JTextArea;

// clase separada que maneja unicamente la logica de alturas y rotaciones
public class RotadorAVL {
    private JTextArea logDestino;

    public RotadorAVL(JTextArea logDestino) {
        this.logDestino = logDestino;
    }

    public int obtenerAltura(NodoTurno nodo) {
        return nodo == null ? 0 : nodo.altura;
    }

    public int obtenerBalance(NodoTurno nodo) {
        return nodo == null ? 0 : obtenerAltura(nodo.derecho) - obtenerAltura(nodo.izquierdo);
    }

    public void actualizarAltura(NodoTurno nodo) {
        if (nodo != null) {
            nodo.altura = 1 + Math.max(obtenerAltura(nodo.izquierdo), obtenerAltura(nodo.derecho));
        }
    }

    public NodoTurno rotarIzquierda(NodoTurno x) {
        logDestino.append("rotacion simple izquierda aplicada en turno " + x.turno + "\n");
        NodoTurno y = x.derecho;
        NodoTurno temp = y.izquierdo;

        y.izquierdo = x;
        x.derecho = temp;

        actualizarAltura(x);
        actualizarAltura(y);

        return y;
    }

    public NodoTurno rotarDerecha(NodoTurno y) {
        logDestino.append("rotacion simple derecha aplicada en turno " + y.turno + "\n");
        NodoTurno x = y.izquierdo;
        NodoTurno temp = x.derecho;

        x.derecho = y;
        y.izquierdo = temp;

        actualizarAltura(y);
        actualizarAltura(x);

        return x;
    }

    // metodo extraido exactamente como pediste para la insercion
    public NodoTurno aplicarRotacion(NodoTurno nodo, int fe, int turno) {
        if (fe < -1 && turno < nodo.izquierdo.turno) {
            return rotarDerecha(nodo);
        }
        if (fe > 1 && turno > nodo.derecho.turno) {
            return rotarIzquierda(nodo);
        }
        if (fe < -1 && turno > nodo.izquierdo.turno) {
            logDestino.append("balance doble detectado primero izquierda luego derecha\n");
            nodo.izquierdo = rotarIzquierda(nodo.izquierdo);
            return rotarDerecha(nodo);
        }
        if (fe > 1 && turno < nodo.derecho.turno) {
            logDestino.append("balance doble detectado primero derecha luego izquierda\n");
            nodo.derecho = rotarDerecha(nodo.derecho);
            return rotarIzquierda(nodo);
        }
        return nodo;
    }

    // metodo extraido para balancear al momento de eliminar un turno
    public NodoTurno aplicarRotacionEliminacion(NodoTurno nodo, int fe) {
        if (fe < -1 && obtenerBalance(nodo.izquierdo) <= 0) {
            return rotarDerecha(nodo);
        }
        if (fe < -1 && obtenerBalance(nodo.izquierdo) > 0) {
            nodo.izquierdo = rotarIzquierda(nodo.izquierdo);
            return rotarDerecha(nodo);
        }
        if (fe > 1 && obtenerBalance(nodo.derecho) >= 0) {
            return rotarIzquierda(nodo);
        }
        if (fe > 1 && obtenerBalance(nodo.derecho) < 0) {
            nodo.derecho = rotarDerecha(nodo.derecho);
            return rotarIzquierda(nodo);
        }
        return nodo;
    }
}