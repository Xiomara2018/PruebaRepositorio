package clinica;

import javax.swing.JTextArea;

// estructura del arbol avl que delega las rotaciones a una clase externa
public class ArbolAVLClinica {
    private NodoTurno raiz;
    private JTextArea logDestino;
    private RotadorAVL rotador;

    public ArbolAVLClinica(JTextArea logDestino) {
        this.logDestino = logDestino;
        this.rotador = new RotadorAVL(logDestino);
    }

    public NodoTurno getRaiz() {
        return raiz;
    }

    public int obtenerBalance(NodoTurno nodo) {
        return rotador.obtenerBalance(nodo);
    }

    public int contarPacientes() {
        return contarNodos(raiz);
    }

    private int contarNodos(NodoTurno nodo) {
        if (nodo == null) {
            return 0;
        }
        return 1 + contarNodos(nodo.izquierdo) + contarNodos(nodo.derecho);
    }

    public void insertar(int turno) {
        raiz = insertarRecursivo(raiz, turno);
    }

    private NodoTurno insertarRecursivo(NodoTurno nodo, int turno) {
        if (nodo == null) {
            return new NodoTurno(turno);
        }

        if (turno < nodo.turno) {
            nodo.izquierdo = insertarRecursivo(nodo.izquierdo, turno);
        } else if (turno > nodo.turno) {
            nodo.derecho = insertarRecursivo(nodo.derecho, turno);
        } else {
            logDestino.append("el turno " + turno + " ya esta registrado\n");
            return nodo;
        }

        rotador.actualizarAltura(nodo);
        int fe = rotador.obtenerBalance(nodo);

        return rotador.aplicarRotacion(nodo, fe, turno);
    }

    public void atenderSiguiente() {
        if (raiz == null) {
            logDestino.append("no hay pacientes en espera en este momento\n");
            return;
        }
        int turnoMinimo = buscarMinimoValor(raiz);
        logDestino.append("atendiendo al paciente con el turno " + turnoMinimo + "\n");
        raiz = eliminarRecursivo(raiz, turnoMinimo);
    }

    private int buscarMinimoValor(NodoTurno nodo) {
        while (nodo.izquierdo != null) {
            nodo = nodo.izquierdo;
        }
        return nodo.turno;
    }

    // nuevo metodo clave para pintar de verde al proximo paciente
    public NodoTurno obtenerNodoMinimo() {
        if (raiz == null) {
            return null;
        }
        NodoTurno actual = raiz;
        while (actual.izquierdo != null) {
            actual = actual.izquierdo;
        }
        return actual;
    }

    private NodoTurno eliminarRecursivo(NodoTurno nodo, int turno) {
        if (nodo == null) {
            return null;
        }

        if (turno < nodo.turno) {
            nodo.izquierdo = eliminarRecursivo(nodo.izquierdo, turno);
        } else if (turno > nodo.turno) {
            nodo.derecho = eliminarRecursivo(nodo.derecho, turno);
        } else {
            if (nodo.izquierdo == null || nodo.derecho == null) {
                NodoTurno temp = (nodo.izquierdo != null) ? nodo.izquierdo : nodo.derecho;
                if (temp == null) {
                    nodo = null;
                } else {
                    nodo = temp;
                }
            } else {
                int sucesorValor = buscarMinimoValor(nodo.derecho);
                nodo.turno = sucesorValor;
                nodo.derecho = eliminarRecursivo(nodo.derecho, sucesorValor);
            }
        }

        if (nodo == null) {
            return null;
        }

        rotador.actualizarAltura(nodo);
        int fe = rotador.obtenerBalance(nodo);

        return rotador.aplicarRotacionEliminacion(nodo, fe);
    }

    // nueva funcion de busqueda para el boton buscar
    public boolean buscar(int turno) {
        return buscarRecursivo(raiz, turno);
    }

    private boolean buscarRecursivo(NodoTurno nodo, int turno) {
        if (nodo == null) {
            return false;
        }
        if (turno == nodo.turno) {
            return true;
        }
        if (turno < nodo.turno) {
            return buscarRecursivo(nodo.izquierdo, turno);
        } else {
            return buscarRecursivo(nodo.derecho, turno);
        }
    }

    // nueva funcion de recorrido inorden para probar que sea bst
    public void imprimirInorden() {
        if (raiz == null) {
            logDestino.append("arbol vacio sin elementos\n");
            return;
        }
        logDestino.append("recorrido inorden ");
        inordenRecursivo(raiz);
        logDestino.append("\n");
    }

    private void inordenRecursivo(NodoTurno nodo) {
        if (nodo != null) {
            inordenRecursivo(nodo.izquierdo);
            logDestino.append(nodo.turno + " ");
            inordenRecursivo(nodo.derecho);
        }
    }
}