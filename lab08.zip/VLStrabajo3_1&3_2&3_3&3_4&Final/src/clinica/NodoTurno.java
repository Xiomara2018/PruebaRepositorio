package clinica;

// clase que representa el nodo del arbol avl para los turnos de la clinica
public class NodoTurno {
    public int turno;
    public int altura;
    public NodoTurno izquierdo;
    public NodoTurno derecho;

    public NodoTurno(int turno) {
        this.turno = turno;
        this.altura = 1;
    }
}