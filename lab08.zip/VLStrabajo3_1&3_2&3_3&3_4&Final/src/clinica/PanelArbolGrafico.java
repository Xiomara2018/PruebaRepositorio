package clinica;

import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// panel encargado del renderizado grafico del arbol avl en la pantalla
public class PanelArbolGrafico extends JPanel {
    private ArbolAVLClinica arbol;
    private final int radioNodo = 20;
    private final int espacioVertical = 50;

    // variables para las nuevas funcionalidades visuales
    private int turnoBuscado = -1;
    private int turnoAnimado = -1;
    private Timer temporizadorAnimacion;

    public PanelArbolGrafico(ArbolAVLClinica arbol) {
        this.arbol = arbol;
        setBackground(new Color(245, 245, 245));
        setPreferredSize(new Dimension(2000, 1000));

        // configuramos el temporizador para la animacion de insercion
        temporizadorAnimacion = new Timer(400, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                turnoAnimado = -1;
                repaint();
                temporizadorAnimacion.stop();
            }
        });
    }

    // permite cambiar el arbol cuando usamos el boton limpiar
    public void setArbol(ArbolAVLClinica nuevoArbol) {
        this.arbol = nuevoArbol;
        this.turnoBuscado = -1;
        this.turnoAnimado = -1;
        repaint();
    }

    public void resaltarBusqueda(int turno) {
        this.turnoBuscado = turno;
        repaint();
    }

    public void animarTurno(int turno) {
        this.turnoAnimado = turno;
        repaint();
        temporizadorAnimacion.restart();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (arbol != null && arbol.getRaiz() != null) {
            dibujarNodo(g2, arbol.getRaiz(), 1000, 40, 250);
        } else {
            g2.setColor(new Color(150, 150, 150));
            g2.setFont(new Font("sansserif", Font.ITALIC, 14));
            g2.drawString("sala de espera vacia sin turnos por mostrar", 20, 30);
        }
    }

    private void dibujarNodo(Graphics2D g, NodoTurno nodo, int x, int y, int desplazarX) {
        if (nodo == null) {
            return;
        }

        g.setStroke(new BasicStroke(2));

        int nuevoDesplazamiento = Math.max(25, desplazarX / 2);

        if (nodo.izquierdo != null) {
            g.setColor(new Color(180, 180, 180));
            g.drawLine(x, y, x - desplazarX, y + espacioVertical);
            dibujarNodo(g, nodo.izquierdo, x - desplazarX, y + espacioVertical, nuevoDesplazamiento);
        }

        if (nodo.derecho != null) {
            g.setColor(new Color(180, 180, 180));
            g.drawLine(x, y, x + desplazarX, y + espacioVertical);
            dibujarNodo(g, nodo.derecho, x + desplazarX, y + espacioVertical, nuevoDesplazamiento);
        }

        // sombra sutil para hacer el diseño un toque mas bonito
        g.setColor(new Color(0, 0, 0, 30));
        g.fillOval(x - radioNodo + 2, y - radioNodo + 2, radioNodo * 2, radioNodo * 2);

        // logica ux de colores mejorada
        if (nodo.turno == turnoBuscado) {
            g.setColor(new Color(255, 215, 0)); // amarillo para busquedas
        } else if (nodo.turno == turnoAnimado) {
            g.setColor(new Color(255, 105, 180)); // rosa para animar nueva insercion
        } else if (nodo == arbol.obtenerNodoMinimo()) {
            g.setColor(new Color(50, 205, 50)); // verde indicando que es el proximo a salir
        } else if (nodo == arbol.getRaiz()) {
            g.setColor(new Color(255, 140, 0)); // naranja para la raiz
        } else if (nodo.izquierdo == null && nodo.derecho == null) {
            g.setColor(new Color(135, 206, 250)); // celeste para las hojas
        } else {
            g.setColor(new Color(70, 130, 180)); // azul estandar
        }

        g.fillOval(x - radioNodo, y - radioNodo, radioNodo * 2, radioNodo * 2);
        g.setColor(Color.white);
        g.setStroke(new BasicStroke(2));
        g.drawOval(x - radioNodo, y - radioNodo, radioNodo * 2, radioNodo * 2);

        // pinta el numero del turno
        g.setColor(Color.white);
        if (nodo.turno == turnoBuscado) g.setColor(Color.black); // texto oscuro si es amarillo
        g.setFont(new Font("sansserif", Font.BOLD, 12));
        String textoTurno = String.valueOf(nodo.turno);
        FontMetrics fm = g.getFontMetrics();
        int anchoTexto = fm.stringWidth(textoTurno);
        int altoTexto = fm.getAscent();
        g.drawString(textoTurno, x - (anchoTexto / 2), y + (altoTexto / 2) - 2);

        // dibuja el factor de equilibrio bf debajo del nodo
        int factorEq = arbol.obtenerBalance(nodo);
        g.setColor(new Color(100, 100, 100));
        g.setFont(new Font("sansserif", Font.BOLD, 10));
        g.drawString("bf " + factorEq, x - 10, y + radioNodo + 14);
    }
}