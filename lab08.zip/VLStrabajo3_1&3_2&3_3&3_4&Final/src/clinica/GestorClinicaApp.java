package clinica;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestorClinicaApp extends JFrame {
    private ArbolAVLClinica arbol;
    private PanelArbolGrafico panelGrafico;
    private JTextField txtTurno;
    private JTextArea areaLog;
    private JLabel lblContador;
    private JButton btnAtender;
    private JButton btnRegistrar;
    private JButton btnBuscar;
    private JButton btnInorden;
    private JButton btnLimpiar;
    private JScrollPane scrollGrafico;

    public GestorClinicaApp() {
        setTitle("gestor de turnos clinica santa maria");
        setSize(950, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        areaLog = new JTextArea(8, 30);
        areaLog.setEditable(false);
        areaLog.setFont(new Font("monospaced", Font.PLAIN, 12));
        areaLog.setBackground(new Color(240, 245, 250));

        DefaultCaret caret = (DefaultCaret) areaLog.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        JScrollPane scrollLog = new JScrollPane(areaLog);
        scrollLog.setBorder(BorderFactory.createTitledBorder("registro de operaciones"));

        arbol = new ArbolAVLClinica(areaLog);
        panelGrafico = new PanelArbolGrafico(arbol);
        scrollGrafico = new JScrollPane(panelGrafico);
        scrollGrafico.setBorder(BorderFactory.createEmptyBorder());

        // panel principal de controles con layout mas amigable
        JPanel panelControles = new JPanel();
        panelControles.setBackground(new Color(220, 230, 240));
        panelControles.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JLabel lblTurno = new JLabel("turno");
        lblTurno.setFont(new Font("sansserif", Font.BOLD, 12));
        txtTurno = new JTextField(6);

        btnRegistrar = new JButton("registrar");
        btnBuscar = new JButton("buscar");
        btnAtender = new JButton("atender siguiente");
        btnInorden = new JButton("ver inorden");
        btnLimpiar = new JButton("limpiar todo");

        lblContador = new JLabel("esperando 0");
        lblContador.setFont(new Font("sansserif", Font.BOLD, 12));
        lblContador.setForeground(new Color(40, 80, 120));

        panelControles.add(lblTurno);
        panelControles.add(txtTurno);
        panelControles.add(btnRegistrar);
        panelControles.add(btnBuscar);
        panelControles.add(btnAtender);
        panelControles.add(btnInorden);
        panelControles.add(btnLimpiar);
        panelControles.add(new JLabel(" | "));
        panelControles.add(lblContador);

        // acciones del teclado
        txtTurno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnRegistrar.doClick();
            }
        });

        // listener para registrar
        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int valorTurno = Integer.parseInt(txtTurno.getText().trim());
                    if (valorTurno <= 0) {
                        areaLog.append("error el turno debe ser mayor a cero\n");
                        return;
                    }
                    areaLog.append("intentando registrar el turno " + valorTurno + "\n");
                    arbol.insertar(valorTurno);
                    txtTurno.setText("");
                    panelGrafico.resaltarBusqueda(-1); // quita marcas viejas
                    panelGrafico.animarTurno(valorTurno); // lanza animacion rosada
                    actualizarInterfazUX();
                } catch (NumberFormatException ex) {
                    areaLog.append("ingrese un numero de turno valido\n");
                }
            }
        });

        // listener para busqueda
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int valorTurno = Integer.parseInt(txtTurno.getText().trim());
                    if (arbol.buscar(valorTurno)) {
                        areaLog.append("turno " + valorTurno + " encontrado en el arbol\n");
                        panelGrafico.resaltarBusqueda(valorTurno); // pinta de amarillo
                    } else {
                        areaLog.append("el turno " + valorTurno + " no existe en espera\n");
                        panelGrafico.resaltarBusqueda(-1);
                    }
                } catch (NumberFormatException ex) {
                    areaLog.append("ingrese un numero valido para buscar\n");
                }
            }
        });

        // listener para atender
        btnAtender.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                arbol.atenderSiguiente();
                panelGrafico.resaltarBusqueda(-1);
                actualizarInterfazUX();
            }
        });

        // listener inorden
        btnInorden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                arbol.imprimirInorden();
            }
        });

        // listener para limpiar con confirmacion
        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int respuesta = JOptionPane.showConfirmDialog(
                        GestorClinicaApp.this,
                        "seguro que deseas reiniciar todo el arbol avl",
                        "confirmar limpieza",
                        JOptionPane.YES_NO_OPTION
                );

                if (respuesta == JOptionPane.YES_OPTION) {
                    arbol = new ArbolAVLClinica(areaLog);
                    panelGrafico.setArbol(arbol);
                    areaLog.setText("sistema reiniciado por completo\n");
                    actualizarInterfazUX();
                }
            }
        });

        setLayout(new BorderLayout());
        add(panelControles, BorderLayout.NORTH);
        add(scrollGrafico, BorderLayout.CENTER);
        add(scrollLog, BorderLayout.SOUTH);

        actualizarInterfazUX();
    }

    private void actualizarInterfazUX() {
        boolean hayNodos = arbol.getRaiz() != null;
        btnAtender.setEnabled(hayNodos);
        btnBuscar.setEnabled(hayNodos);
        btnInorden.setEnabled(hayNodos);
        lblContador.setText("esperando " + arbol.contarPacientes());
        panelGrafico.repaint();
        scrollGrafico.revalidate();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GestorClinicaApp().setVisible(true);
            }
        });
    }
}