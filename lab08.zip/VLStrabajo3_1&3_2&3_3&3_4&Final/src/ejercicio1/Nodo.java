package ejercicio1;

public class Nodo {
    public int dato, altura;
    Nodo izq, der; 
    Nodo(int dato) {
        this.dato = dato;
        this.altura = 1;
    }
}