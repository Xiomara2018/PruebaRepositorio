package ejercicio1;

import Exceptions.ItemDuplicated;

public class GetorTickets {
    private NodeG<Integer> root;
    // Variable booleana global requerida por la plantilla para rastrear si la altura cambió
    private boolean alturacb; 

    public void insert(Integer data) throws ItemDuplicated {
        this.alturacb = false;
        root = insert(root, data);
    }

    //3.2
    private NodeG<Integer> insert(NodeG<Integer> node, Integer data) throws ItemDuplicated {
        if (node == null) {
            this.alturacb = true;//informara que la altura cambio
            return new NodeG<Integer>(data);
        }

        int comp = node.data.compareTo(data);
        if (comp > 0) {
            node.left = insert(node.left, data);
            
            //mientra regresa po la ruta ,evalua i eta balanceado 
            if (this.alturacb) {
                switch (node.bf) {
                    case 1:  
                    	node.bf = 0;  
                    	this.alturacb = false; 
                    	break;
                    case 0:  
                    	node.bf = -1; 
                    	this.alturacb = true;  
                    	break;
                    case -1: 
                    	//si llega -2 ,se llama al balanceo
                    	node = balanceToRight(node); 
                    	this.alturacb = false; 
                    	break;
                    
                }
            }
        } else if (comp < 0) {
            node.right = insert(node.right, data);
          //mientra regresa por la ruta ,evalua si esta balanceado 
            if (this.alturacb) {
                switch (node.bf) {
                    case -1: 
                    	node.bf = 0; 
                    	this.alturacb = false; break;
                    case 0:  
                    	node.bf = 1; 
                    	this.alturacb = true;  break;
                  //si llega 2 ,se llama al balanceo
                    case 1:  
                    	node = balanceToLeft(node); 
                    	this.alturacb = false; 
                    	break;
                }
            }
        } else {
            throw new ItemDuplicated("Dato duplicado");
        }

        return node;
    }

    //3.3
    private NodeG<Integer> balanceToLeft(NodeG<Integer> node) {
        NodeG<Integer> hijo = node.right;
        switch (hijo.bf) {
            case 1: // Derecha Derecha
                node.bf = 0;
                hijo.bf = 0;
                node = rotateSL(node);
                break;
                
            case -1: // Derecha Izquierda
                NodeG<Integer> nieto = hijo.left;
                switch (nieto.bf) {
                    case -1:node.bf = 0;hijo.bf = 1;break;
                    case 0:node.bf = 0;hijo.bf = 0;break;
                    case 1:node.bf = -1;hijo.bf = 0;break;
                }
                nieto.bf = 0;
                node.right = rotateSR(hijo);
                node = rotateSL(node);
                break;
                
            case 0: //para eliminacion
                node.bf = 1;
                hijo.bf = -1;
                node = rotateSL(node);
                break;
        }
        return node;
    }

    private NodeG<Integer> balanceToRight(NodeG<Integer> node) {
        NodeG<Integer> hijo = node.left;
        switch (hijo.bf) {
            case -1: // izq izq
                node.bf = 0;
                hijo.bf = 0;
                node = rotateSR(node);
                break;
                
            case 1: // izq der
                NodeG<Integer> nieto = hijo.right;
                switch (nieto.bf) {
                    case -1: node.bf = 1;  hijo.bf = 0; break;
                    case 0:  node.bf = 0;  hijo.bf = 0; break;
                    case 1:  node.bf = 0;  hijo.bf = -1; break;
                }
                nieto.bf = 0;
                node.left = rotateSL(hijo);
                node = rotateSR(node);
                break;
                
            case 0: // eliminacion
                node.bf = -1;
                hijo.bf = 1;
                node = rotateSR(node);
                break;
        }
        return node;
    }


    private NodeG<Integer> rotateSL(NodeG<Integer> node) {
        NodeG<Integer> newRoot = node.right;
        node.right = newRoot.left;
        newRoot.left = node;
        return newRoot;
    }

    private NodeG<Integer> rotateSR(NodeG<Integer> node) {
        NodeG<Integer> newRoot = node.left;
        node.left = newRoot.right;
        newRoot.right = node;
        return newRoot;
    }

    //metoo de buqueda
    
    public boolean search(Integer data) {
        return search(root, data);
    }

    private boolean search(NodeG<Integer> node, Integer data) {
        if (node == null) return false;
        int comp = node.data.compareTo(data);
        if (comp > 0) return search(node.left, data);
        else if (comp < 0) return search(node.right, data);
        else return true; // encontrado
    }
    
    //Eliminacion
    
    public void remove(Integer data) {
        this.alturacb = false;
        root = remove(root, data);
    }

    private NodeG<Integer> remove(NodeG<Integer> node, Integer data) {
        if (node == null) {
            System.out.println("El ticket " + data + " no existe.");
            return null;
        }

        int comp = node.data.compareTo(data);
        if (comp > 0) {
            node.left = remove(node.left, data);
            if (this.alturacb) { // Al borrar a la izquierda el arbol terendra que inclinar a la derecha
                switch (node.bf) {
                    case -1: node.bf = 0; this.alturacb = true; break;
                    case 0:  node.bf = 1; this.alturacb = false; break;
                    case 1:  node = balanceToLeft(node); break; 
                }
            }
        } else if (comp < 0) {
            node.right = remove(node.right, data);
            if (this.alturacb) { // Al borrar a la derecha el arbol se inclina a la izquierda
                switch (node.bf) {
                    case 1:  node.bf = 0; this.alturacb = true; break;
                    case 0:  node.bf = -1; this.alturacb = false; break;
                    case -1: node = balanceToRight(node); break;
                }
            }
        } else {//aqui es cuando encuentra
            // Caso 1 o 2
            if (node.left == null) {
                this.alturacb = true;
                return node.right;
            } else if (node.right == null) {
                this.alturacb = true;
                return node.left;
            } else {
                // Caso 3: Dos hijos buscar el sucesor en inorden
                NodeG<Integer> successor = getMin(node.right);
                node.data = successor.data;
                node.right = remove(node.right, successor.data);
                if (this.alturacb) {
                    switch (node.bf) {
                        case 1:  node.bf = 0; this.alturacb = true; break;
                        case 0:  node.bf = -1; this.alturacb = false; break;
                        case -1: node = balanceToRight(node); break;
                    }
                }
            }
        }
        return node;
    }

    private NodeG<Integer> getMin(NodeG<Integer> node) {
        while (node.left != null) node = node.left;
        return node;
    }

   
    
    public void inOrder() {
        inOrder(root);
        System.out.println();
    }

    private void inOrder(NodeG<Integer> node) {
        if (node != null) {
            inOrder(node.left);
            System.out.print(node.data + " ");
            inOrder(node.right);
        }
    }
    
    public void printTree() {
        printTree(root, "", true);
    }

    private void printTree(NodeG<Integer> node, String prefix, boolean isRoot) {
        if (node != null) {
            System.out.println(prefix + (isRoot ? "└── " : "├── ") + node.data + " (bf=" + node.bf + ")");
            if (node.left != null || node.right != null) {
                printTree(node.left, prefix + "   ", false);
                printTree(node.right, prefix + "   ", false);
            }
        }
    }
}