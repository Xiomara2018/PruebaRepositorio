package ejercicio1;
import Exceptions.ItemDuplicated;

public class MainTickets {
    public static void main(String[] args) {
    	GetorTickets gestor = new GetorTickets();
        int[] ticketsAIngresar = {30, 10, 20, 40, 50, 25};

        for (int ticket : ticketsAIngresar) {
            try {
                System.out.println("ticket Nr " + ticket +"insertado");
                gestor.insert(ticket);
                gestor.printTree();
            } catch (ItemDuplicated e) {
                System.out.println( e.getMessage());
            }
        }

        System.out.print("inorder ");
        gestor.inOrder();

        System.out.print("Buscamos los tickets 20,60 ");
        int[] ticketsABuscar = {20, 60};
        for (int ticket : ticketsABuscar) {
            System.out.println("¿Ticket encontrado?" + (gestor.search(ticket)));
        }

        System.out.print("Buscamos los tickets 10.40.30 ");
        int[] ticketsAEliminar = {10, 40, 30};

        for (int ticket : ticketsAEliminar) {
            System.out.println("Eliminando ticket número: " + ticket);
            gestor.remove(ticket);
            gestor.printTree();
        }

        System.out.println("\n=================================================");
        System.out.print("Tickets restantes inorder ");
        gestor.inOrder();
    }
}