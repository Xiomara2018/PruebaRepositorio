package ejercicio2;

public class BST {

    public NodoBST raiz;

    //  INSERCIÓN

    public void insertar(int dato) {
        raiz = insertar(raiz, dato);
    }

    private NodoBST insertar(NodoBST n, int dato) {
        if (n == null)         return new NodoBST(dato);
        if (dato < n.dato)     n.izq = insertar(n.izq, dato);
        else if (dato > n.dato) n.der = insertar(n.der, dato);
        return n; // duplicados ignorados
    }

    //  BÚSQUEDA

    public boolean buscar(int dato) {
        return buscar(raiz, dato);
    }

    private boolean buscar(NodoBST n, int dato) {
        if (n == null)       return false;
        if (dato == n.dato)  return true;
        if (dato < n.dato)   return buscar(n.izq, dato);
        return buscar(n.der, dato);
    }

    //  ALTURA

    public int altura() {
        return altura(raiz);
    }

    private int altura(NodoBST n) {
        if (n == null) return 0;
        return 1 + Math.max(altura(n.izq), altura(n.der));
    }

    //  RECORRIDOS
    
    public void inorden() {
        System.out.print("  InOrden  BST : ");
        inorden(raiz);
        System.out.println();
    }

    private void inorden(NodoBST n) {
        if (n != null) {
            inorden(n.izq);
            System.out.print(n.dato + " ");
            inorden(n.der);
        }
    }

    public void preorden() {
        System.out.print("  PreOrden BST : ");
        preorden(raiz);
        System.out.println();
    }

    private void preorden(NodoBST n) {
        if (n != null) {
            System.out.print(n.dato + " ");
            preorden(n.izq);
            preorden(n.der);
        }
    }

    public void mostrarArbol() {
        mostrarArbol(raiz, "  ", true);
    }

    private void mostrarArbol(NodoBST n, String p, boolean isRoot) {
        if (n != null) {
            System.out.println(p + (isRoot ? "L-- " : "|-- ") + n.dato);
            if (n.izq != null || n.der != null) {
                mostrarArbol(n.izq, p + "    ", false);
                mostrarArbol(n.der, p + "    ", false);
            }
        }
    }
}