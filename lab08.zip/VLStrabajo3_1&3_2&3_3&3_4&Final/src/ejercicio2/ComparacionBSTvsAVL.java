package ejercicio2;

import VLS_Generico.AVL;
import VLS_Generico.Nodo;

public class ComparacionBSTvsAVL {

    static int alturaAVL(Nodo n) {
        return n == null ? 0 : n.altura;
    }

    static boolean buscarAVL(Nodo n, int dato) {
        if (n == null)      return false;
        if (dato == n.dato) return true;
        return dato < n.dato ? buscarAVL(n.izq, dato) : buscarAVL(n.der, dato);
    }

    static void inordenAVL(Nodo n) {
        if (n != null) {
            inordenAVL(n.izq);
            System.out.print(n.dato + " ");
            inordenAVL(n.der);
        }
    }

    static void preordenAVL(Nodo n) {
        if (n != null) {
            System.out.print(n.dato + "(h=" + n.altura + ") ");
            preordenAVL(n.izq);
            preordenAVL(n.der);
        }
    }

    static void mostrarAVL(Nodo n, String p, boolean isRoot) {
        if (n != null) {
            System.out.println(p + (isRoot ? "L-- " : "|-- ") + n.dato + " (h=" + n.altura + ")");
            if (n.izq != null || n.der != null) {
                mostrarAVL(n.izq, p + "    ", false);
                mostrarAVL(n.der, p + "    ", false);
            }
        }
    }

    static void probar(String titulo, int[] datos, int[] buscar) {
        System.out.println("\n--- " + titulo + " ---");
        System.out.print("datos: ");
        for (int d : datos) System.out.print(d + " ");
        System.out.println("\n");

        BST bst = new BST();
        AVL avl = new AVL();
        for (int d : datos) {
            bst.insertar(d);
            avl.insertar(d);
        }

        System.out.println("BST:");
        bst.mostrarArbol();

        System.out.println("\nAVL:");
        mostrarAVL(avl.raiz, "", true);

        int hBST = bst.altura();
        int hAVL = alturaAVL(avl.raiz);
        System.out.println("\naltura BST: " + hBST);
        System.out.println("altura AVL: " + hAVL);

        System.out.println("\nrecorridos:");
        bst.inorden();
        System.out.print("inorden  AVL: ");
        inordenAVL(avl.raiz);
        System.out.println();
        bst.preorden();
        System.out.print("preorden AVL: ");
        preordenAVL(avl.raiz);
        System.out.println();

        System.out.println("\nbusquedas:");
        for (int b : buscar) {
            System.out.println("  " + b + " -> BST: " + (bst.buscar(b) ? "si" : "no")
                    + "  AVL: " + (buscarAVL(avl.raiz, b) ? "si" : "no"));
        }
    }

    public static void main(String[] args) {
        probar(
            "caso 1: secuencia ascendente",
            new int[]{ 10, 20, 30, 40, 50 },
            new int[]{ 10, 30, 99 }
        );

        probar(
            "caso 2: secuencia mixta",
            new int[]{ 30, 10, 20, 40, 50, 25 },
            new int[]{ 20, 25, 60 }
        );
    }
}