package ejercicio2;

public class NodoBST {
    public int dato;
    public NodoBST izq, der;

    public NodoBST(int dato) {
        this.dato = dato;
        this.izq  = null;
        this.der  = null;
    }
}