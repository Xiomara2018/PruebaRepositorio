package VLS_Generico;

import Exceptions.ItemDuplicated;

public class AlmacenMain {
    public static void main(String[] args) {
        AVLRotacionesG<Producto> inventario = new AVLRotacionesG<>();

        System.out.println("sistema de gestion de almacen arbol avl generico");
        System.out.println("insertando productos para verificar balanceos automaticos\n");

        try {
            // estos ids especificos forzaran rotaciones para evidenciar el comportamiento del avl
            inventario.insert(new Producto("PROD-05", "teclado mecanico", 45, 75.0));
            inventario.insert(new Producto("PROD-03", "mouse gamer", 60, 35.0));
            inventario.insert(new Producto("PROD-01", "alfombrilla xl", 120, 15.0)); // rotacion izquierda izquierda

            inventario.insert(new Producto("PROD-08", "monitor 144hz", 15, 299.9));
            inventario.insert(new Producto("PROD-09", "tarjeta grafica", 10, 650.0)); // rotacion derecha derecha

            inventario.insert(new Producto("PROD-07", "memoria ram 16gb", 35, 55.0)); // rotacion doble compleja

            System.out.println("\nestructura del arbol avl final vista jerarquica");
            inventario.printTree();

            System.out.println("\n======================================================================");
            System.out.println("ejecutando recorrido por amplitud bfs recursivo sin usar colas");
            System.out.println("======================================================================\n");
            inventario.breadthFirstSearch();

        } catch (ItemDuplicated e) {
            System.err.println("error en inventario " + e.getMessage());
        }
    }
}