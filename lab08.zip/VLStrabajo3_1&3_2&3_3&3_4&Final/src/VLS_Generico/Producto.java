package VLS_Generico;

public class Producto implements Comparable<Producto> {
    private String id;
    private String nombre;
    private int stock;
    private double precio;

    public Producto(String id, String nombre, int stock, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.stock = stock;
        this.precio = precio;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public int getStock() { return stock; }
    public double getPrecio() { return precio; }

    @Override
    public int compareTo(Producto otro) {
        return this.id.compareTo(otro.id);
    }

    @Override
    public String toString() {
        return String.format("[%s | %s | Stock: %d | $%.2f]", id, nombre, stock, precio);
    }
}