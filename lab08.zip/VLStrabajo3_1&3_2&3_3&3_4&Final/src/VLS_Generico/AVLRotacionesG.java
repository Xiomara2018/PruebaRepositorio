package VLS_Generico;

import Exceptions.ItemDuplicated;

public class AVLRotacionesG <E extends Comparable<E>> {
    private NodeG<E> root;

    public void insert(E data) throws ItemDuplicated {
        root = insert(root, data);
    }

    private NodeG<E> insert(NodeG<E> node, E data) throws ItemDuplicated {
        // 1. Insertar como árbol binario de búsqueda
        if (node == null) {
            return new NodeG<E>(data);
        }
        int comp = node.data.compareTo(data);
        if (comp > 0) {
            node.left = insert(node.left, data);
        } else if (comp < 0) {
            node.right = insert(node.right, data);
        } else {
            throw new ItemDuplicated("Dato duplicado");
        }

        // 2. Actualizar factor de equilibrio
        node.bf = height(node.right) - height(node.left);

        // 3. Verificar desbalance hacia la izquierda
        if (node.bf < -1) {
            // Caso Izquierda-Derecha
            if (node.left.bf > 0) {
                System.out.println("Caso detectado: Izquierda-Derecha");
                node.left = rotateLeft(node.left);
                return rotateRight(node);
            }
            // Caso Izquierda-Izquierda
            System.out.println("Caso detectado: Izquierda-Izquierda");
            return rotateRight(node);
        }

        // 4. Verificar desbalance hacia la derecha
        if (node.bf > 1) {
            // Caso Derecha-Izquierda
            if (node.right.bf < 0) {
                System.out.println("Caso detectado: Derecha-Izquierda");
                node.right = rotateRight(node.right);
                return rotateLeft(node);
            }
            // Caso Derecha-Derecha
            System.out.println("Caso detectado: Derecha-Derecha");
            return rotateLeft(node);
        }
        return node;
    }

    private NodeG<E> rotateLeft(NodeG<E> node) {
        NodeG<E> newRoot = node.right;
        NodeG<E> temp = newRoot.left;
        newRoot.left = node;
        node.right = temp;

        node.bf = height(node.right) - height(node.left);
        newRoot.bf = height(newRoot.right) - height(newRoot.left);
        return newRoot;
    }

    private NodeG<E> rotateRight(NodeG<E> node) {
        NodeG<E> newRoot = node.left;
        NodeG<E> temp = newRoot.right;
        newRoot.right = node;
        node.left = temp;

        node.bf = height(node.right) - height(node.left);
        newRoot.bf = height(newRoot.right) - height(newRoot.left);
        return newRoot;
    }

    private int height(NodeG<E> node) {
        if (node == null) {
            return 0;
        }
        return 1 + Math.max(height(node.left), height(node.right));
    }

    public void printTree() {
        printTree(root, "", true);
    }

    private void printTree(NodeG<E> node, String prefix, boolean isRoot) {
        if (node != null) {
            System.out.println(prefix + (isRoot ? "└── " : "├── ") + node);
            if (node.left != null || node.right != null) {
                printTree(node.left, prefix + "   ", false);
                printTree(node.right, prefix + "   ", false);
            }
        }
    }

    //ej 4 y 5
    public void breadthFirstSearch() {
        int h = height(root);
        for (int i = 1; i <= h; i++) {
            System.out.println("--- Nivel " + i + " ---");
            printGivenLevel(root, i);
            System.out.println();
        }
    }

    private void printGivenLevel(NodeG<E> node, int level) {
        if (node == null) {
            return;
        }
        if (level == 1) {
            System.out.print(node.data + " ");
        } else if (level > 1) {
            // desciende disminuyendo el contador
            printGivenLevel(node.left, level - 1);
            printGivenLevel(node.right, level - 1);
        }
    }
}