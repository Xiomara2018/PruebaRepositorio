package VLS_de_int_a_generico;

public class AVL {
	public Nodo raiz;
	public int altura(Nodo n) {
	return n == null ? 0 : n.altura;
	}
	
	public int balance(Nodo n) {
		return n == null ? 0 : altura(n.der) - altura(n.izq);
		}
	public void actualizarAltura(Nodo n) {
		n.altura = 1 + Math.max(altura(n.izq), altura(n.der));
		}
	Nodo rotarIzquierda(Nodo x) {
		Nodo y = x.der;
		Nodo temp = y.izq;
		y.izq = x;
		x.der = temp;
		actualizarAltura(x);
		actualizarAltura(y);
		return y;
		}
	
	Nodo rotarDerecha(Nodo y) {
		Nodo x = y.izq;
		Nodo temp = x.der;
		x.der = y;
		y.izq = temp;
		actualizarAltura(y);
		actualizarAltura(x);
		return x;
		}
	public void insertar(int dato) {
		raiz = insertar(raiz, dato);
		}
		Nodo insertar(Nodo nodo, int dato) {
		if (nodo == null)
		return new Nodo(dato);
		if (dato < nodo.dato) {
		nodo.izq = insertar(nodo.izq, dato);
		} else if (dato > nodo.dato) {
		nodo.der = insertar(nodo.der, dato);
		} else {
		return nodo;
		}
		actualizarAltura(nodo);
		int bf = balance(nodo);
		// Caso Derecha-Derecha
		if (bf > 1 && dato > nodo.der.dato)
		return rotarIzquierda(nodo);
		// Caso Izquierda-Izquierda
		if (bf < -1 && dato < nodo.izq.dato)
		return rotarDerecha(nodo);
		// Caso Izquierda-Derecha
		if (bf < -1 && dato > nodo.izq.dato) {
		nodo.izq = rotarIzquierda(nodo.izq);
		return rotarDerecha(nodo);
		}
		// Caso Derecha-Izquierda
		if (bf > 1 && dato < nodo.der.dato) {
		nodo.der = rotarDerecha(nodo.der);
		return rotarIzquierda(nodo);
		}
		return nodo;
		}
	public void inorden(Nodo n) {
		if (n != null) {
		inorden(n.izq);
		System.out.print(n.dato + " ");
		inorden(n.der);
		}
		}
	public void mostrar() {
		inorden(raiz);
		System.out.println();
		}
}



