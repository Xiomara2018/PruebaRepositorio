package VLS_de_int_a_generico;
import Exceptions.ItemDuplicated;

public class AVLTREEG <E extends Comparable<E>>{
	private NodeG<E> root;
	
	public void insert(E data) throws ItemDuplicated{
		root = insert(root , data);
	}
	
	
	private NodeG<E> insert(NodeG<E> node , E data) throws ItemDuplicated {
		if (node == null) {
			return new NodeG<E>(data);	
		}
		
		int comp = node.data.compareTo(data);
		
		if(comp > 0) {//si node.data es mayor que data es menor
			node.left = insert(node.left, data);
		}else if (comp < 0) {//lo contrario 
			node.right = insert(node.right, data);
		}else {
			throw new ItemDuplicated("El dato ya existe");
		}
		
				
		// Act factor de equilibrio
		node.bf = height(node.right) - height(node.left);
		
		
		// si se desbalancea hacia la derecha
		if (node.bf > 1) {
		System.out.println("Desbalance en nodo " + node.data);
		System.out.println("Se aplica rotacion simple izquierda");
		return rotateLeft(node);
		}
		// si se desbalancea hacia la izquierda
		if (node.bf < -1) {
		System.out.println("Desbalance en nodo " + node.data);
		System.out.println("Se aplica rotación simple derecha");
		return rotateRight(node);
		}

		return node;
	}
	
	
	private NodeG<E> rotateLeft(NodeG<E> node) {
		NodeG<E> newRoot = node.right;
		NodeG<E> temp = newRoot.left;
		
		newRoot.left = node;
		node.right = temp;
		
		// actualiza factores despues de rotar
		node.bf = height(node.right) - height(node.left);
		newRoot.bf = height(newRoot.right) - height(newRoot.left);
		return newRoot;
	
	}
		
	private NodeG<E> rotateRight(NodeG<E> node) {
		NodeG<E> newRoot = node.left;
		NodeG<E> temp = newRoot.right;
		newRoot.right = node;
		node.left = temp;
		// actualiza factores despues de rotar
		node.bf = height(node.right) - height(node.left);
		newRoot.bf = height(newRoot.right) - height(newRoot.left);
		return newRoot;
		}
	
	private int height(NodeG<E> node) {
		if (node == null) {
		return 0;
		}
		return 1 + Math.max(height(node.left), height(node.right));
		}
		public void printTree() {
		printTree(root, "", true);
		}
		private void printTree(NodeG<E> node, String space, boolean isRoot) {
		if (node != null) {
		System.out.println(space + (isRoot ? "└── " : "├── ") + node);
		printTree(node.left, space + " ", false);
		printTree(node.right, space + " ", false);
			}
		}	
		
		
		
		
		
}
