package VLS_de_int_a_generico;

public class Nodo {
	public int dato, altura;
	public Nodo izq, der;
	Nodo(int dato) {
		this.dato = dato;
		this.altura = 1;
	}
}