module ejercicio7 {
}