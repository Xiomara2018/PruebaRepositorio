package ejercicio7;

import java.util.LinkedList;
import java.util.Queue;

public class AVLTree<T extends Comparable<T>> {

    Nodo<T> raiz;
    boolean alturacb;

    // INSERTAR
    Nodo<T> insertar(Nodo<T> n, T v) {

        if (n == null) {
            alturacb = true;
            return new Nodo<>(v);
        }

        if (v.compareTo(n.valor) < 0) {
            n.izq = insertar(n.izq, v);

            if (alturacb) {
                if (n.bf == 1) {
                    n.bf = 0;
                    alturacb = false;
                } else if (n.bf == 0) {
                    n.bf = -1;
                    alturacb = true;
                } else {
                    n = balancearDerecha(n);
                    alturacb = false;
                }
            }

        } else if (v.compareTo(n.valor) > 0) {
            n.der = insertar(n.der, v);

            if (alturacb) {
                if (n.bf == -1) {
                    n.bf = 0;
                    alturacb = false;
                } else if (n.bf == 0) {
                    n.bf = 1;
                    alturacb = true;
                } else {
                    n = balancearIzquierda(n);
                    alturacb = false;
                }
            }
        }

        return n;
    }

    // ROTACIONES
    Nodo<T> rotarIzquierda(Nodo<T> n) {
        Nodo<T> x = n.der;
        n.der = x.izq;
        x.izq = n;
        return x;
    }

    Nodo<T> rotarDerecha(Nodo<T> n) {
        Nodo<T> x = n.izq;
        n.izq = x.der;
        x.der = n;
        return x;
    }

    // BALANCEAR IZQUIERDA (RR y RL)
    Nodo<T> balancearIzquierda(Nodo<T> n) {
        Nodo<T> hijo = n.der;

        if (hijo.bf == 1) { // RR
            n.bf = 0;
            hijo.bf = 0;
            n = rotarIzquierda(n);

        } else { // RL
            Nodo<T> nieto = hijo.izq;

            if (nieto.bf == 1) n.bf = -1;
            else n.bf = 0;

            if (nieto.bf == -1) hijo.bf = 1;
            else hijo.bf = 0;

            nieto.bf = 0;

            n.der = rotarDerecha(hijo);
            n = rotarIzquierda(n);
        }

        return n;
    }

    // BALANCEAR DERECHA (LL y LR)
    Nodo<T> balancearDerecha(Nodo<T> n) {
        Nodo<T> hijo = n.izq;

        if (hijo.bf == -1) { // LL
            n.bf = 0;
            hijo.bf = 0;
            n = rotarDerecha(n);

        } else { // LR
            Nodo<T> nieto = hijo.der;

            if (nieto.bf == -1) n.bf = 1;
            else n.bf = 0;

            if (nieto.bf == 1) hijo.bf = -1;
            else hijo.bf = 0;

            nieto.bf = 0;

            n.izq = rotarIzquierda(hijo);
            n = rotarDerecha(n);
        }

        return n;
    }

    // MÉTODO PÚBLICO INSERTAR
    void add(T v) {
        alturacb = false;
        raiz = insertar(raiz, v);
    }

    // ELIMINAR
    void delete(T v) {
        alturacb = false;
        raiz = eliminar(raiz, v);
    }

    Nodo<T> eliminar(Nodo<T> n, T v) {

        if (n == null) return null;

        if (v.compareTo(n.valor) < 0) {
            n.izq = eliminar(n.izq, v);

            if (alturacb) {
                if (n.bf == -1) {
                    n.bf = 0;
                    alturacb = true;
                } else if (n.bf == 0) {
                    n.bf = 1;
                    alturacb = false;
                } else {
                    n = balancearIzquierda(n);
                }
            }

        } else if (v.compareTo(n.valor) > 0) {
            n.der = eliminar(n.der, v);

            if (alturacb) {
                if (n.bf == 1) {
                    n.bf = 0;
                    alturacb = true;
                } else if (n.bf == 0) {
                    n.bf = -1;
                    alturacb = false;
                } else {
                    n = balancearDerecha(n);
                }
            }

        } else {

            if (n.izq == null) {
                alturacb = true;
                return n.der;
            } else if (n.der == null) {
                alturacb = true;
                return n.izq;
            } else {
                Nodo<T> temp = getMin(n.der);
                n.valor = temp.valor;
                n.der = eliminar(n.der, temp.valor);

                if (alturacb) {
                    if (n.bf == 1) {
                        n.bf = 0;
                        alturacb = true;
                    } else if (n.bf == 0) {
                        n.bf = -1;
                        alturacb = false;
                    } else {
                        n = balancearDerecha(n);
                    }
                }
            }
        }

        return n;
    }

    Nodo<T> getMin(Nodo<T> n) {
        while (n.izq != null) n = n.izq;
        return n;
    }
    // RECORRIDO POR NIVELES (COLA)
    void porNiveles() {
        if (raiz == null) {
            System.out.println("Árbol vacío");
            return;
        }
        Queue<Nodo<T>> cola = new LinkedList<>();
        cola.add(raiz);
        System.out.println("\nÁrbol por niveles:");
        while (!cola.isEmpty()) {
            Nodo<T> actual = cola.poll();
            System.out.print(actual.valor + " ");
            if (actual.izq != null) cola.add(actual.izq);
            if (actual.der != null) cola.add(actual.der);
        }
    }
}