package ejercicio7;

public class main {
    public static void main(String[] args) {

        AVLTree<Integer> arbol = new AVLTree<>();

        // INSERTAR (provoca rotaciones)
        arbol.add(10);
        arbol.add(20);
        arbol.add(30);
        arbol.add(40);
        arbol.add(50);
        arbol.add(25);

        System.out.println("Antes de eliminar:");
        arbol.porNiveles();

        // ELIMINAR (provoca nuevas rotaciones)
        arbol.delete(30);
        arbol.delete(10);
        arbol.delete(50);

        System.out.println("\nDespués de eliminar:");
        arbol.porNiveles();
    }
}