package ejercicio7;
class Nodo<T> {
    T valor;
    int bf; // factor de balance (-1, 0, 1)
    Nodo<T> izq, der;

    Nodo(T v) {
        valor = v;
        bf = 0;
    }
}