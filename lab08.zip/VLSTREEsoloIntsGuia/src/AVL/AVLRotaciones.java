package AVL;

public class AVLRotaciones {
	private Node root;
	public void insert(int data) {
		root = insert(root, data);
	}
	private Node insert(Node node, int data) {
		
		// 1. Insertar como árbol binario de búsqueda
		if (node == null) {
		return new Node(data);
		}
		if (data < node.data) {
		node.left = insert(node.left, data);
		} else if (data > node.data) {
		node.right = insert(node.right, data);
		} else {
		return node; // no se permiten duplicados
		}

		// 2. Actualizar factor de equilibrio
		node.bf = height(node.right) - height(node.left);
		// 3. Verificar desbalance hacia la izquierda
		if (node.bf < -1) {
			
			// Caso Izquierda-Derecha
			if (data > node.left.data) {
			System.out.println("Caso detectado: Izquierda-Derecha");
			System.out.println("Primero rotación simple izquierda en " + node.left.data);
			node.left = rotateLeft(node.left);
			System.out.println("Luego rotación simple derecha en " + node.data);
			return rotateRight(node);
			}

			// Caso Izquierda-Izquierda
			System.out.println("Caso detectado: Izquierda-Izquierda");
			System.out.println("Rotación simple derecha en " + node.data);
			return rotateRight(node);
		}

		// 4. Verificar desbalance hacia la derecha
		if (node.bf > 1) {
			// Caso Derecha-Izquierda
			if (data < node.right.data) {
				System.out.println("Caso detectado: Derecha-Izquierda");
				System.out.println("Primero rotación simple derecha en " + node.right.data);
				node.right = rotateRight(node.right);
				
				System.out.println("Luego rotación simple izquierda en " + node.data);
				return rotateLeft(node);
				}
			
				System.out.println("Caso detectado: Derecha-Derecha");
				return rotateLeft(node);
			}
		return node;
		}
		private Node rotateLeft(Node node) {
			Node newRoot = node.right;
			Node temp = newRoot.left;
			newRoot.left = node;
			node.right = temp;
		
			// Actualizar factores de equilibrio después de rotar
			node.bf = height(node.right) - height(node.left);
			newRoot.bf = height(newRoot.right) - height(newRoot.left);
			return newRoot;
		}
		private Node rotateRight(Node node) {
			Node newRoot = node.left;
			Node temp = newRoot.right;
			newRoot.right = node;
			node.left = temp;
			// Actualizar factores de equilibrio después de rotar
			node.bf = height(node.right) - height(node.left);
			newRoot.bf = height(newRoot.right) - height(newRoot.left);
			return newRoot;
		}
		
		private int height(Node node) {
			if (node == null) {
				return 0;
				}
			return 1 + Math.max(height(node.left), height(node.right));
		}
		
		public void printTree() {
			printTree(root, "", true);
		}
		private void printTree(Node node, String prefix, boolean isRoot) {
			if (node != null) {
			System.out.println(prefix + (isRoot ? "└── " : "├── ") + node);
			if (node.left != null || node.right != null) {
			printTree(node.left, prefix + "   ", false);
			printTree(node.right, prefix + "   ", false);
			}
		}
	}
}
