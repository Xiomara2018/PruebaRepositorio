package AVL;

public class Node {
	public int data;
	public int bf;
	public Node left ;
	public Node right ;	
	
	
	public Node(int data) {
		this.data = data;
		this.bf = 0;
		this.right = null;
		this.left = null;
	}
	
	
	//construtor para nodo hijos
	public Node(int data, int bf,Node left, Node right) {
		this.data = data;
        this.left = left;
        this.right = right;
        
    }


	public int getData() {
		return data;
	}


	public void setData(int data) {
		this.data = data;
	}
		
	public String toString() {
		return data + "(bf=" + bf + ")";
		}
	
	
}

