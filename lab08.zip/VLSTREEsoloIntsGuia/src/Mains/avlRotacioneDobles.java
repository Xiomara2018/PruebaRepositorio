package Mains;


import AVL.AVLRotaciones;

public class avlRotacioneDobles {
	public static void main(String[] args) {
			probarCaso("CASO 1: Izquierda-Izquierda",new int[] { 30, 20, 10 });
			probarCaso("CASO 2: Derecha-Derecha",new int[] { 10, 20, 30 });
			probarCaso("CASO 3: Izquierda-Derecha",new int[] { 30, 10, 20 });
			probarCaso("CASO 4: Derecha-Izquierda",new int[] { 10, 30, 20 });
	}
	public static void probarCaso(String titulo, int[] valores) {
	System.out.println("\n====================================");
	System.out.println(titulo);
	System.out.println("====================================");
	AVLRotaciones avl = new AVLRotaciones();
	
	for (int valor : valores) {
		System.out.println("\nInsertando: " + valor);
		avl.insert(valor);
		avl.printTree();
	}
		System.out.println("\nÁrbol final balanceado:");
		avl.printTree();
	}
}
