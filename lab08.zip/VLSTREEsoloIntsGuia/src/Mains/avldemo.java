package Mains;

import AVL.AVLTREE;

public class avldemo {
	public static void main(String[] args) {
		AVLTREE avl = new AVLTREE();
		
		
		System.out.println("Insertando 10");
		avl.insert(10);
		avl.printTree();
		
		System.out.println("\nInsertando 20");
		avl.insert(20);
		avl.printTree();

		System.out.println("\nInsertando 30");
		avl.insert(30);
		avl.printTree();
	}
}
