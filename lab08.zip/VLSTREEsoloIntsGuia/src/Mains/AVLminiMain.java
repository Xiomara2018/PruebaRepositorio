package Mains;
import AVL.*;

public class AVLminiMain {
	public static void main(String[] args) {
		AVL arbol = new AVL();
		int[] datos = { 40, 30, 20, 60 };
		for (int x : datos) { 
			arbol.insertar(x);
		}
		System.out.println("Recorrido inorden del AVL:");
		arbol.mostrar();
		System.out.println("Raíz final: " + arbol.raiz.dato);
	}
}
