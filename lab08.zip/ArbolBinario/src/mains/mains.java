package mains;
import EstructuraEnla.*;

public class mains {
    public static void main(String[] args) {
        LinkedBST<Integer> arbol = new LinkedBST<>();

        try {
            System.out.println("datos inertados: 15, 8, 22, 5, 12, 18, 30");
            int[] datos = {15, 8, 22, 5, 12, 18, 30};
            for (int d : datos) {
                arbol.insertDiv(d);
            }

            System.out.println("Parenthesize");
            arbol.parenthesize();

            //recorridos

            System.out.print("InOrder");
            arbol.inOrder();
            System.out.print("PreOrder: ");
            arbol.preOrder();
            System.out.print("PostOrder: ");
            arbol.postOrder();

            // Orden Descendente
            System.out.print("Orden Descendente: ");
            arbol.printDescending();
            // Busqueda
            System.out.println("Busqueda");
            System.out.println( arbol.search(5));

            // verificacion si el arbol es valido 
            System.out.println("¿Es valido?: " + arbol.isValidBST()); // 

            // eliminar
            System.out.println("caso con dos hijos");
            arbol.remove(8);
            System.out.print("nuevo arbol ");
            arbol.inOrder();

        } catch (ItemDuplicated e) {
            System.out.println("Error: " + e.getMessage()); // [cite: 345]
        } catch (ItemNotfound e) {
            System.out.println("Error: " + e.getMessage()); // 
        } catch (ExceptionIsEmpty e) {
            System.out.println("Error: " + e.getMessage()); // [cite: 355]
        }
    }
}