package VLS_Generico;

public class NodeG<E> {
    public E data; 
    public int bf;
    public NodeG<E> left;
    public NodeG<E> right;    
    
    // Constructor principal
    public NodeG(E data) {
        this.data = data;
        this.bf = 0;
        this.right = null;
        this.left = null;
    }

    public NodeG(E data, int bf) {
        this.data = data;
        this.bf = bf;
        this.right = null;
        this.left = null;
    }

    public void setData(E data) {
        this.data = data;
    }
        
    @Override
    public String toString() {
        return data + " (bf=" + bf + ")";
    }
}

