package VLS_Generico;

import Exceptions.ItemDuplicated;

public class AVLRotacionesG <E extends Comparable<E>>{
	private NodeG<E> root;

	
	public void insert(E data)throws ItemDuplicated {
		root = insert(root, data);
	}
	private NodeG<E> insert(NodeG<E> node, E data) throws ItemDuplicated {
		

		// 1. Insertar como árbol binario de búsqueda
		
		if (node == null) {
		return new NodeG<E>(data);
		}
		int comp = node.data.compareTo(data);
		if (comp > 0) {
		node.left = insert(node.left, data);
		} else if (comp < 0) {
		node.right = insert(node.right, data);
		} else {
			throw new ItemDuplicated("dato duplicado");
		}
		


		// 2. Actualizar factor de equilibrio
		node.bf = height(node.right) - height(node.left);
		// 3. Verificar desbalance hacia la izquierda
		if (node.bf < -1) {
			
			// Caso Izquierda-Derecha
			if (node.left.bf > 0) {
			System.out.println("Caso detectado: Izquierda-Derecha");
			System.out.println("Primero rotación simple izquierda en " + node.left.data);
			node.left = rotateLeft(node.left);
			System.out.println("Luego rotación simple derecha en " + node.data);
			return rotateRight(node);
			}

			// Caso Izquierda-Izquierda
			System.out.println("Caso detectado: Izquierda-Izquierda");
			System.out.println("Rotación simple derecha en " + node.data);
			return rotateRight(node);
		}

		// 4. Verificar desbalance hacia la derecha
		if (node.bf > 1) {
			// Caso Derecha-Izquierda
			if (node.right.bf < 0) {
				System.out.println("Caso detectado: Derecha-Izquierda");
				System.out.println("Primero rotación simple derecha en " + node.right.data);
				node.right = rotateRight(node.right);
				
				System.out.println("Luego rotación simple izquierda en " + node.data);
				return rotateLeft(node);
				}
			
				System.out.println("Caso detectado: Derecha-Derecha");
				return rotateLeft(node);
			}
		return node;
		}
		private NodeG<E> rotateLeft(NodeG<E> node) {
			NodeG<E> newRoot = node.right;
			NodeG<E> temp = newRoot.left;
			newRoot.left = node;
			node.right = temp;
		
			// Actualizar factores de equilibrio después de rotar
			node.bf = height(node.right) - height(node.left);
			newRoot.bf = height(newRoot.right) - height(newRoot.left);
			return newRoot;
		}
		private NodeG<E> rotateRight(NodeG<E> node) {
			NodeG<E> newRoot = node.left;
			NodeG<E> temp = newRoot.right;
			newRoot.right = node;
			node.left = temp;
			// Actualizar factores de equilibrio después de rotar
			node.bf = height(node.right) - height(node.left);
			newRoot.bf = height(newRoot.right) - height(newRoot.left);
			return newRoot;
		}
		
		
		
		
		
		
		
		private int height(NodeG<E> node) {
			if (node == null) {
				return 0;
				}
			return 1 + Math.max(height(node.left), height(node.right));
		}
		
		public void printTree() {
			printTree(root, "", true);
		}
		private void printTree(NodeG<E> node, String prefix, boolean isRoot) {
			if (node != null) {
			System.out.println(prefix + (isRoot ? "└── " : "├── ") + node);
			if (node.left != null || node.right != null) {
			printTree(node.left, prefix + "   ", false);
			printTree(node.right, prefix + "   ", false);
			}
		}
	}
}
