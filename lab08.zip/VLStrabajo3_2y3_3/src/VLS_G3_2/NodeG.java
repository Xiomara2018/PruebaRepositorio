package VLS_G3_2;

public class NodeG<E> {
    public E data; 
    public int bf;
    public NodeG<E> left;
    public NodeG<E> right;    
    
    public NodeG(E data) {
        this.data = data;
        this.bf = 0;
        this.right = null;
        this.left = null;
    }

    public void setData(E data) {
        this.data = data;
    }
        
    @Override
    public String toString() {
        return data + " (bf=" + bf + ")";
    }
}

