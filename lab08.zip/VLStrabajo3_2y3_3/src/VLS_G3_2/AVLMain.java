package VLS_G3_2;

import Exceptions.ItemDuplicated;

public class AVLMain {
    public static void main(String[] args) {
        AVLTREE<Integer> arbol = new AVLTREE<>();
        int[] datosAInsertar = {50, 25, 75, 15, 35, 85, 30};

        for (int valor : datosAInsertar) {
            try {
                System.out.println(" " + valor);
                arbol.insert(valor);
            } catch (ItemDuplicated e) {
                System.out.println( e.getMessage());
            }
        }

        System.out.println("\n=========================================");
        arbol.printTree();

        System.out.println("verificar duplicados");
        try {
            System.out.println(" verificar si hay 35" );
            arbol.insert(35);
        } catch (ItemDuplicated e) {
            System.out.println(" cap " + e.getMessage());
        }
    }
}