package VLS_G3_2;

import Exceptions.ItemDuplicated;

public class AVLmainPreorder {
    public static void main(String[] args) {
        AVLTREE<Integer> arbol1 = new AVLTREE<>();
        try {
            arbol1.insert(10);
            arbol1.insert(20);
            arbol1.insert(30);
        } catch (ItemDuplicated e) {
       
        }

        System.out.println("estructura visual del arbol 10,20,30");
        arbol1.printTree();

        System.out.print("Preorden se supone que es 20 10 30: ");
        arbol1.preOrder();


        System.out.println("   arbol  secuencia cruzada 30, 10, 20");

        AVLTREE<Integer> arbol2 = new AVLTREE<>();
        try {
            arbol2.insert(30);
            arbol2.insert(10);
            arbol2.insert(20);
        } catch (ItemDuplicated e) {
        	
        }
        arbol2.printTree();

        System.out.print("tenria que salir 20 10 30: ");
        arbol2.preOrder();
    }
}
