package VLS_G3_2;

import Exceptions.ItemDuplicated;

public class AVLTREE <E extends Comparable<E>> {
    private NodeG<E> root;
    // Variable booleana global requerida por la plantilla para rastrear si la altura cambió
    private boolean alturacb; 

    public void insert(E data) throws ItemDuplicated {
        this.alturacb = false;
        root = insert(root, data);
    }

    //3.2
    private NodeG<E> insert(NodeG<E> node, E data) throws ItemDuplicated {
        if (node == null) {
            this.alturacb = true;//informara que la altura cambio
            return new NodeG<E>(data);
        }

        int comp = node.data.compareTo(data);
        if (comp > 0) {
            node.left = insert(node.left, data);
            
            //mientra regresa po la ruta ,evalua i eta balanceado 
            if (this.alturacb) {
                switch (node.bf) {
                    case 1:  
                    	node.bf = 0;  
                    	this.alturacb = false; 
                    	break;
                    case 0:  
                    	node.bf = -1; 
                    	this.alturacb = true;  
                    	break;
                    case -1: 
                    	//si llega -2 ,se llama al balanceo
                    	node = balanceToRight(node); 
                    	this.alturacb = false; 
                    	break;
                    
                }
            }
        } else if (comp < 0) {
            node.right = insert(node.right, data);
          //mientra regresa por la ruta ,evalua si esta balanceado 
            if (this.alturacb) {
                switch (node.bf) {
                    case -1: 
                    	node.bf = 0; 
                    	this.alturacb = false; break;
                    case 0:  
                    	node.bf = 1; 
                    	this.alturacb = true;  break;
                  //si llega 2 ,se llama al balanceo
                    case 1:  
                    	node = balanceToLeft(node); 
                    	this.alturacb = false; 
                    	break;
                }
            }
        } else {
            throw new ItemDuplicated("Dato duplicado");
        }

        return node;
    }

    //3.3
    private NodeG<E> balanceToLeft(NodeG<E> node) {
        NodeG<E> hijo = node.right;
        switch (hijo.bf) {
            case 1: // Derecha Derecha
                node.bf = 0;
                hijo.bf = 0;
                node = rotateSL(node);
                break;
                
            case -1: // Derecha Izquierda
                NodeG<E> nieto = hijo.left;
                switch (nieto.bf) {
                    case -1:node.bf = 0;hijo.bf = 1;break;
                    case 0:node.bf = 0;hijo.bf = 0;break;
                    case 1:node.bf = -1;hijo.bf = 0;break;
                }
                nieto.bf = 0;
                node.right = rotateSR(hijo);
                node = rotateSL(node);
                break;
                
            case 0: //para eliminacion
                node.bf = 1;
                hijo.bf = -1;
                node = rotateSL(node);
                break;
        }
        return node;
    }

    private NodeG<E> balanceToRight(NodeG<E> node) {
        NodeG<E> hijo = node.left;
        switch (hijo.bf) {
            case -1: // izq izq
                node.bf = 0;
                hijo.bf = 0;
                node = rotateSR(node);
                break;
                
            case 1: // izq der
                NodeG<E> nieto = hijo.right;
                switch (nieto.bf) {
                    case -1: node.bf = 1;  hijo.bf = 0; break;
                    case 0:  node.bf = 0;  hijo.bf = 0; break;
                    case 1:  node.bf = 0;  hijo.bf = -1; break;
                }
                nieto.bf = 0;
                node.left = rotateSL(hijo);
                node = rotateSR(node);
                break;
                
            case 0: // eliminacion
                node.bf = -1;
                hijo.bf = 1;
                node = rotateSR(node);
                break;
        }
        return node;
    }


    private NodeG<E> rotateSL(NodeG<E> node) {
        NodeG<E> newRoot = node.right;
        node.right = newRoot.left;
        newRoot.left = node;
        return newRoot;
    }

    private NodeG<E> rotateSR(NodeG<E> node) {
        NodeG<E> newRoot = node.left;
        node.left = newRoot.right;
        newRoot.right = node;
        return newRoot;
    }

    public void preOrder() {
        preOrder(root);
        System.out.println();
    }

    //Raiz - Izquierda - Derecha
    private void preOrder(NodeG<E> node) {
        if (node != null) {
            System.out.print(node.data + " ");
            preOrder(node.left);
            preOrder(node.right);
        }
    }
    
    
    
    public void printTree() {
        printTree(root, "", true);
    }

    private void printTree(NodeG<E> node, String prefix, boolean isRoot) {
        if (node != null) {
            System.out.println(prefix + (isRoot ? "└── " : "├── ") + node.data + " (bf=" + node.bf + ")");
            if (node.left != null || node.right != null) {
                printTree(node.left, prefix + "   ", false);
                printTree(node.right, prefix + "   ", false);
            }
        }
    }
}